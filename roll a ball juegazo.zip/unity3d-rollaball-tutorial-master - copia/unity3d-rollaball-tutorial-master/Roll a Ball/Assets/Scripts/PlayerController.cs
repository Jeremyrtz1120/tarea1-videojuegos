﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    [Header("Movimiento")]
    public float speed = 8f;

    [Header("UI del juego")]
    public Text countText;      // "Counter"
    public Text winText;        // "You Win" / derrota

    [Header("Nombre en pantalla")]
    public Text nameText;       // marca de agua
    public string myName = "Jeremy";

    [Header("Temporizador")]
    public Text timerText;      // MM:SS
    public float startSeconds = 60f;

    private Rigidbody rb;
    private int count;
    private float timeLeft;
    private bool timerRunning = true;
    private bool hasWon = false;

    void Start ()
    {
        rb = GetComponent<Rigidbody>();

        count = 0;
        SetCountText();
        if (winText  != null) winText.text = "";
        if (nameText != null) nameText.text = myName;

        timeLeft = Mathf.Max(0f, startSeconds);
        UpdateTimerLabel(timeLeft);
    }

    void Update()
    {
        if (timerRunning && !hasWon)
        {
            timeLeft -= Time.deltaTime;
            if (timeLeft <= 0f)
            {
                timeLeft = 0f;
                UpdateTimerLabel(timeLeft);
                Lose();
                return;
            }
            UpdateTimerLabel(timeLeft);
        }
    }

    void FixedUpdate()
    {
        if (!timerRunning || hasWon) { StopMovement(); return; }

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(h, 0f, v);
        rb.AddForce(movement * speed);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pickup"))
        {
            other.gameObject.SetActive(false);
            count += 1;
            SetCountText();
        }
    }

    void SetCountText()
    {
        if (countText != null) countText.text = "Count: " + count;

        // Ajusta 12 al total real de tus pickups
        if (count >= 12)
        {
            hasWon = true;
            if (winText != null) winText.text = "You Win!";
            StopTimer();
            StopMovement();
        }
    }

    void UpdateTimerLabel(float t)
    {
        if (!timerText) return;
        int minutes = Mathf.FloorToInt(t / 60f);
        int seconds = Mathf.FloorToInt(t % 60f);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    void StopTimer() { timerRunning = false; }

    // ---- perder → volver a menú (Build Settings index 0) ----
    void Lose()
    {
        timerRunning = false;
        hasWon = false;
        if (winText != null) winText.text = "¡Tiempo agotado! Perdiste";
        StopMovement();

        // Espera en tiempo real (no afectado por Time.timeScale)
        StartCoroutine(LoadMenuAfterRealtime(1.0f));
    }

    System.Collections.IEnumerator LoadMenuAfterRealtime(float seconds)
    {
        yield return new WaitForSecondsRealtime(seconds);

        // Asegúrate que la escena de menú esté en Build Settings con índice 0
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
        // Si prefieres por nombre:
        // SceneManager.LoadScene("mainmenu");
    }
    // ---------------------------------------------------------

    void StopMovement()
    {
        if (!rb) return;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }
}
